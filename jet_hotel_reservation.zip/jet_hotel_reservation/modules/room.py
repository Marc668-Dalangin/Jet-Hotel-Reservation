from utils.file_handler import read_json, write_json

ROOMS_FILE = 'data/rooms.json'

def list_available_rooms():
    rooms = read_json(ROOMS_FILE)
    return [room for room in rooms if room['available']]

def add_room(room_number, room_type, price):
    rooms = read_json(ROOMS_FILE)
    new_room = {
        'room_number': room_number,
        'room_type': room_type,
        'price': price,
        'available': True
    }
    rooms.append(new_room)
    write_json(ROOMS_FILE, rooms)

def update_room_availability(room_number, status):
    rooms = read_json(ROOMS_FILE)
    for room in rooms:
        if room['room_number'] == room_number:
            room['available'] = status
    write_json(ROOMS_FILE, rooms)