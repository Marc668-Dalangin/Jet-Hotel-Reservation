from modules.reservation import get_reservations_by_date
from modules.guest import get_guest

def daily_transaction_report(target_date):
    reservations = get_reservations_by_date(target_date)
    report = []
    for res in reservations:
        guest = get_guest(res['guest_id'])
        report.append({
            'Reservation ID': res['reservation_id'],
            'Guest Name': guest['name'],
            'Room Number': res['room_number'],
            'Check-in': res['check_in'],
            'Check-out': res['check_out'],
            'Date': res['reservation_date']
        })
    return report