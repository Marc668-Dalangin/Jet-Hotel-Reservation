from utils.file_handler import read_json, write_json
from modules.room import update_room_availability
from datetime import date

RESERVATIONS_FILE = 'data/reservations.json'

def make_reservation(guest_id, room_number, check_in, check_out):
    reservations = read_json(RESERVATIONS_FILE)
    reservation_id = len(reservations) + 1
    new_reservation = {
        'reservation_id': reservation_id,
        'guest_id': guest_id,
        'room_number': room_number,
        'check_in': check_in,
        'check_out': check_out,
        'reservation_date': str(date.today())
    }
    reservations.append(new_reservation)
    write_json(RESERVATIONS_FILE, reservations)
    update_room_availability(room_number, False)
    return reservation_id

def get_reservations_by_date(target_date):
    reservations = read_json(RESERVATIONS_FILE)
    return [res for res in reservations if res['reservation_date'] == target_date]