from utils.file_handler import read_json, write_json

GUESTS_FILE = 'data/guests.json'

def add_guest(name, contact):
    guests = read_json(GUESTS_FILE)
    guest_id = len(guests) + 1
    new_guest = {
        'guest_id': guest_id,
        'name': name,
        'contact': contact
    }
    guests.append(new_guest)
    write_json(GUESTS_FILE, guests)
    return guest_id

def get_guest(guest_id):
    guests = read_json(GUESTS_FILE)
    for guest in guests:
        if guest['guest_id'] == guest_id:
            return guest
    return None