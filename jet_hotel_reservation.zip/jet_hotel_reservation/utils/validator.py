from datetime import datetime
import re
from modules.room import list_available_rooms

def validate_name(name):
    return bool(name.strip())

def validate_contact(contact):
    return bool(re.fullmatch(r'\d{7,15}', contact))

def validate_date(date_text):
    try:
        datetime.strptime(date_text, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def validate_date_order(check_in, check_out):
    return datetime.strptime(check_out, '%Y-%m-%d') > datetime.strptime(check_in, '%Y-%m-%d')

def validate_room_number(room_number):
    rooms = list_available_rooms()
    return any(room['room_number'] == room_number for room in rooms)

def validate_menu_choice(choice, options):
    return choice in options
from datetime import datetime
import re
from modules.room import list_available_rooms

def validate_name(name):
    return bool(name.strip())

def validate_contact(contact):
    return bool(re.fullmatch(r'\d{7,15}', contact))

def validate_date(date_text):
    try:
        datetime.strptime(date_text, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def validate_date_order(check_in, check_out):
    return datetime.strptime(check_out, '%Y-%m-%d') > datetime.strptime(check_in, '%Y-%m-%d')

def validate_room_number(room_number):
    rooms = list_available_rooms()
    return any(room['room_number'] == room_number for room in rooms)

def validate_menu_choice(choice, options):
    return choice in options