from modules import room, guest, reservation, transaction_report
from utils import validator
from datetime import date

def display_rooms():
    rooms = room.list_available_rooms()
    if not rooms:
        print("No available rooms.")
    for r in rooms:
        print(f"Room {r['room_number']} - {r['room_type']} - ${r['price']}")

def reserve_room():
    while True:
        name = input("Enter your name: ")
        if validator.validate_name(name):
            break
        print("Name cannot be empty.")

    while True:
        contact = input("Enter contact number: ")
        if validator.validate_contact(contact):
            break
        print("Invalid contact number format.")

    guest_id = guest.add_guest(name, contact)
    display_rooms()

    while True:
        room_number = input("Select room number: ")
        if validator.validate_room_number(room_number):
            break
        print("Invalid room number or not available.")

    while True:
        check_in = input("Check-in date (YYYY-MM-DD): ")
        if validator.validate_date(check_in):
            break
        print("Invalid date format.")

    while True:
        check_out = input("Check-out date (YYYY-MM-DD): ")
        if validator.validate_date(check_out) and validator.validate_date_order(check_in, check_out):
            break
        print("Check-out must be a valid date after check-in.")

    res_id = reservation.make_reservation(guest_id, room_number, check_in, check_out)
    print(f"\nReservation successful! Your Reservation ID is {res_id}")

def view_daily_transactions():
    today = str(date.today())
    report = transaction_report.daily_transaction_report(today)
    if not report:
        print("No transactions today.")
    else:
        print(f"\n--- Transactions on {today} ---")
        for r in report:
            print(r)

def main_menu():
    while True:
        print("\n--- Jet Hotel Reservation System ---")
        print("1. View Available Rooms")
        print("2. Reserve a Room")
        print("3. View Daily Transactions")
        print("4. Exit")

        choice = input("Choose an option: ")
        print(" ")

        if not validator.validate_menu_choice(choice, ['1', '2', '3', '4']):
            print("Invalid choice.")
            continue

        if choice == '1':
            display_rooms()
        elif choice == '2':
            reserve_room()
        elif choice == '3':
            view_daily_transactions()
        elif choice == '4':
            print("Goodbye!")
            break

if __name__ == "__main__":
    main_menu()